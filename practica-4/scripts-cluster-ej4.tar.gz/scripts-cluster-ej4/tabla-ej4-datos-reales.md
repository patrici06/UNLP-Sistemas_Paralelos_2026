# Ejercicio 4 - MPI Matrix Multiplication (Datos Reales)

## Tabla resumen

| N    | P | T_Seq (s) | T_Par (s) | T_Comm (s) | Speedup | Eficiencia |
|------|---|-----------|-----------|------------|---------|------------|
| 512  | 1 | 1.601323  | 1.601323  | 0.000004   | N/A     | N/A        |
| 512  | 4 | 1.601323  | 0.409775  | 0.009381   | 3.90756 | 0.97689    |
| 512  | 8 | 1.601323  | 0.293583  | 0.093361   | 5.45443 | 0.68180    |
| 1024 | 1 | 12.998812 | 12.998812 | 0.000005   | N/A     | N/A        |
| 1024 | 4 | 12.998812 | 3.301078  | 0.039613   | 3.93788 | 0.98447    |
| 1024 | 8 | 12.998812 | 2.002957  | 0.372433   | 6.48482 | 0.81060    |
| 2048 | 1 | 103.608182| 103.608182| 0.000005   | N/A     | N/A        |
| 2048 | 4 | 103.608182| 26.541913 | 0.125132   | 3.90387 | 0.97597    |
| 2048 | 8 | 103.608182| 14.721710 | 1.513615   | 7.04378 | 0.88047    |

## Comparativa por N

### N = 512

| P | T_Seq (s) | T_Par (s) | Speedup | Eficiencia |
|---|-----------|-----------|---------|------------|
| 4 | 1.601323  | 0.409775  | 3.90756 | 0.97689    |
| 8 | 1.601323  | 0.293583  | 5.45443 | 0.68180    |

### N = 1024

| P | T_Seq (s) | T_Par (s) | Speedup | Eficiencia |
|---|-----------|-----------|---------|------------|
| 4 | 12.998812 | 3.301078  | 3.93788 | 0.98447    |
| 8 | 12.998812 | 2.002957  | 6.48482 | 0.81060    |

### N = 2048

| P | T_Seq (s) | T_Par (s) | Speedup | Eficiencia |
|---|-----------|-----------|---------|------------|
| 4 | 103.608182| 26.541913 | 3.90387 | 0.97597    |
| 8 | 103.608182| 14.721710 | 7.04378 | 0.88047    |

## Observaciones

- **Speedup casi ideal** para P=4 en todos los tamanos (~3.9x sobre 4), lo que indica buena aprovechamiento del paralelismo dentro de un nodo.
- **Al pasar a 2 nodos (P=8)** el speedup sigue creciendo pero la eficiencia baja, evidenciando overhead por comunicacion inter-nodo (especialmente visible en T_Comm para P=8).
- **A mayor N, mejor escalabilidad**: para N=2048, P=8 logra eficiencia 0.88 vs 0.68 para N=512, mostrando que el overhead de comunicacion se amortiza con mas computo.
