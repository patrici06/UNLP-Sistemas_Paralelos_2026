#!/bin/bash

parameters_values=(512 1024 2048 4096)

for p in "${parameters_values[@]}"; do
	dir="./${p}-BASE${1}"
	mkdir -p "$dir/outputs"
	mkdir -p "$dir/errors"

	for o in 1 2 3; do
		gcc -O${o} ./re-entrega-matrices.c -o ./re-entregaO${o}
		sleep 2

		echo "Enviando job con parametro=$p O=$o"

		sbatch \
			-o "$dir/outputs/output_O${o}_%j.txt" \
			-e "$dir/errors/error_O${o}_%j.txt" \
			./script-1.sh $p $o
	done
done
